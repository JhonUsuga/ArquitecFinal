package com.udea.parcialFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParcialFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
