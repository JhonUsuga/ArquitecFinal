package com.udea.parcialFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParcialFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParcialFinalApplication.class, args);
	}

}
