package com.udea.parcialFinal.model;

import lombok.Data;

@Data
public class DoctorInput {
    private String cedulaProfesional;
    private String nombre;
    private String especialidad;
}
